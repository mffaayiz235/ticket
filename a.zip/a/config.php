<?php
$title = 'Online Ticket Reservation System';
//E-Ticketing System For Railway
$supervisor_name = "Dr. A. O Ameen";
$developer_name = "Adelabu Oluwatoyin Simbiat";
$developer_matric = "16/52HA016";
